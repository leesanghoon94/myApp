# {{- if .Values.apps.front.enabled }}

# apiVersion: v1

# kind: Service

# metadata:

# name: frontend

# spec:

# selector:

# app: frontend

# ports:

# - port: 80

# targetPort: 80

# ---

# apiVersion: apps/v1

# kind: Deployment

# metadata:

# name: frontend

# spec:

# replicas: 1

# selector:

# matchLabels:

# app: frontend

# template:

# metadata:

# labels:

# app: frontend

# spec:

# containers:

# - name: frontend

# image: leesanghoon94/front-local:v0.0.7

# imagePullPolicy: Always

# ports:

# - containerPort: 80

# resources:

# {{- toYaml .Values.apps.front.resources | nindent 12}}

# ---

# apiVersion: v1

# kind: Service

# metadata:

# name: server

# spec:

# ports:

# - port: 3333

# targetPort: 3333

# selector:

# app: server

# ---

# apiVersion: apps/v1

# kind: Deployment

# metadata:

# name: server

# spec:

# replicas: 1

# selector:

# matchLabels:

# app: server

# template:

# metadata:

# labels:

# app: server

# spec:

# containers:

# - name: server

# image: leesanghoon94/server-local:v0.0.5

# imagePullPolicy: Always

# ports:

# - containerPort: 3333

# resources:

# {{- toYaml .Values.apps.server.resources | nindent 12}}

# {{- end }}

#

<!-- argcdtemplate to yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: test
spec:
  destination:
    namespace: default
    server: https://kubernetes.default.svc
  source:
    path: myapp
    repoURL: https://github.com/leesanghoon94/myApp.git
    targetRevision: main
    helm:
      valueFiles:
        - values.yaml
  sources: []
  project: default -->
